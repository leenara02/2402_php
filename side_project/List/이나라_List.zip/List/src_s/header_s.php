<div class="header">
    <h1>
        <a href="./index_s.php">
            <div class="footprint"><img src="./image_s/footprint.jpg" alt=""></div>
            List
        </a>
    </h1>
</div>